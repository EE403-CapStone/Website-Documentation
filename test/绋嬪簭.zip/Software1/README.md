## README

This is the code base of the our groups EE403w project

Project manager: Erik Huuki